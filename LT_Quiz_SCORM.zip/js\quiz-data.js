// Construction Safety Quiz — 60 questions (source: Construction_Safety_Quiz_60Q.xlsx)
// image: placeholder SVG until real photos/illustrations are produced per 'Visual Brief' column.
// imageCaption: shows the intended visual brief as text until real assets are ready.
var QUIZ_QUESTIONS = [
  {
    category: "PPE",
    question: "What is the primary purpose of a hard hat on a construction site?",
    image: "assets/images/q1.jpg",
    imageCaption: "",
    options: {
      A: "To protect the head from falling or flying objects",
      B: "To keep the sun off the worker's face",
      C: "To identify the worker's department",
      D: "To improve ventilation while working"
    },
    correct: "A"
  },
  {
    category: "PPE",
    question: "Which type of harness must be used for fall-arrest work at height?",
    image: "assets/images/q2.jpg",
    imageCaption: "",
    options: {
      A: "A single waist belt",
      B: "A full-body harness",
      C: "A rope tied around the chest",
      D: "A weightlifting belt"
    },
    correct: "B"
  },
  {
    category: "PPE",
    question: "At what continuous noise level should hearing protection be worn on site?",
    image: "assets/images/q3.jpg",
    imageCaption: "",
    options: {
      A: "Above 85 decibels (8-hour average)",
      B: "Above 30 decibels",
      C: "Only when using a jackhammer",
      D: "Hearing protection is optional on construction sites"
    },
    correct: "A"
  },
  {
    category: "PPE",
    question: "Which eye protection is correct when using an angle grinder?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker grinding steel with sparks flying toward the face",
    options: {
      A: "Regular prescription glasses only",
      B: "Safety goggles or a full face shield",
      C: "Sunglasses",
      D: "No eye protection is needed for short tasks"
    },
    correct: "B"
  },
  {
    category: "PPE",
    question: "Why do workers wear high-visibility (hi-vis) vests on site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Reversing dump truck on site with a worker in a bright orange/yellow vest clearly visible to the driver",
    options: {
      A: "To look fashionable",
      B: "To be easily seen by vehicle and equipment operators",
      C: "To keep warm in cold weather",
      D: "To show seniority on the project"
    },
    correct: "B"
  },
  {
    category: "PPE",
    question: "Where does Personal Protective Equipment (PPE) sit in the hierarchy of hazard controls?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Pyramid diagram: Elimination, Substitution, Engineering, Administrative, PPE at the bottom",
    options: {
      A: "The first and most effective control",
      B: "The last line of defense, used after other controls",
      C: "PPE replaces the need for engineering controls",
      D: "PPE is only needed if a supervisor is watching"
    },
    correct: "B"
  },
  {
    category: "PPE",
    question: "What is the main protection offered by steel-toe / safety boots?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Heavy pipe or block rolling toward a worker's foot wearing safety boots",
    options: {
      A: "Protection from falling or rolling heavy objects onto the foot",
      B: "Making the worker taller",
      C: "Keeping feet cool in summer",
      D: "Improving running speed"
    },
    correct: "A"
  },
  {
    category: "PPE",
    question: "When should a respirator (e.g., N95 mask) be used on site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker cutting concrete with visible dust cloud, wearing a fitted respirator mask",
    options: {
      A: "Only if the worker personally feels like it",
      B: "When working in dusty, fume-laden or hazardous atmospheres",
      C: "Only during lunch break",
      D: "Never — masks are not required in construction"
    },
    correct: "B"
  },
  {
    category: "PPE",
    question: "On a full-body harness, where is the main D-ring for fall arrest normally located?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Rear view of a worker in a harness with the lanyard clipped to a D-ring between the shoulder blades",
    options: {
      A: "On the front of the chest only",
      B: "On the back, between the shoulder blades (dorsal D-ring)",
      C: "On the side of the hip",
      D: "On top of the hard hat"
    },
    correct: "B"
  },
  {
    category: "Work at Height",
    question: "When placing an extension ladder against a wall, what is the safe angle (the 4:1 rule)?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Ladder leaning against a building wall with a worker checking the angle",
    options: {
      A: "About 45 degrees",
      B: "About 75 degrees (1 foot out for every 4 feet of height)",
      C: "Completely vertical (90 degrees)",
      D: "Any angle is fine as long as it touches the wall"
    },
    correct: "B"
  },
  {
    category: "Work at Height",
    question: "What is the minimum standard height for a scaffold top guardrail?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Scaffold platform with a worker standing beside a properly guarded edge",
    options: {
      A: "Around 1.0–1.1 m (about 42 inches) above the platform",
      B: "15 cm (ankle height)",
      C: "Guardrails are optional if the scaffold is low",
      D: "2.5 cm (a thin rope only)"
    },
    correct: "A"
  },
  {
    category: "Work at Height",
    question: "Above what typical height must workers use fall-protection equipment (harness, guardrails, or nets)?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker on an open edge at roughly two-storey height with a harness clipped to an anchor",
    options: {
      A: "About 1.8 m / 6 feet or higher above a lower level",
      B: "Only above 30 m",
      C: "Fall protection is never required outdoors",
      D: "Only when a supervisor happens to be watching"
    },
    correct: "A"
  },
  {
    category: "Work at Height",
    question: "How many points of contact should a worker maintain while climbing a ladder?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Side view of a worker climbing a ladder rung by rung",
    options: {
      A: "One hand, one foot",
      B: "Three points of contact at all times (two hands + one foot, or two feet + one hand)",
      C: "It doesn't matter as long as you climb fast",
      D: "Zero — you can carry tools in both hands while climbing"
    },
    correct: "B"
  },
  {
    category: "Work at Height",
    question: "What should a worker never do while standing on a ladder?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker stretching sideways off a ladder to reach a far point, ladder tipping",
    options: {
      A: "Keep both feet on the same rung, facing the ladder",
      B: "Overreach sideways or lean far off the ladder's centerline",
      C: "Wear a tool belt",
      D: "Keep three points of contact"
    },
    correct: "B"
  },
  {
    category: "Work at Height",
    question: "When are safety nets typically used on a construction site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Safety net rigged beneath a steel structure where workers are erecting beams",
    options: {
      A: "As decoration around the site fence",
      B: "As a fall-arrest system when guardrails or travel restraint are not practical",
      C: "Only to store tools overnight",
      D: "To replace the need for any other fall protection everywhere"
    },
    correct: "B"
  },
  {
    category: "Work at Height",
    question: "What load must a fall-arrest anchor point be rated to support per attached worker?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Close-up of a certified anchor point with a rating tag, lanyard clipped in",
    options: {
      A: "About 5,000 lbs (22 kN), or an engineered system with a safety factor of two",
      B: "50 lbs — any small hook will do",
      C: "Anchor strength does not matter",
      D: "Only as much as the worker's own body weight, no more"
    },
    correct: "A"
  },
  {
    category: "Work at Height",
    question: "How often should a scaffold be inspected?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Competent person with a checklist and tag inspecting a scaffold before shift start",
    options: {
      A: "Once, when it is first built, and never again",
      B: "Before each work shift and after any alteration or severe weather",
      C: "Only if it visibly collapses",
      D: "Once a year regardless of use"
    },
    correct: "B"
  },
  {
    category: "Work at Height",
    question: "What is the purpose of a toe board on a scaffold platform?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Scaffold platform edge with a low board preventing a dropped wrench from falling off",
    options: {
      A: "To decorate the scaffold edge",
      B: "To prevent tools and materials from falling off the platform edge",
      C: "To act as a handrail for climbing",
      D: "To increase the scaffold's height"
    },
    correct: "B"
  },
  {
    category: "Tools Handling",
    question: "What should a worker do if a power tool's safety guard is in the way?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker inspecting a circular saw guard before use, guard intact",
    options: {
      A: "Remove the guard to work faster",
      B: "Never remove the guard — report the issue if it interferes with the task",
      C: "Tape the guard down",
      D: "Use the tool only at night without the guard"
    },
    correct: "B"
  },
  {
    category: "Tools Handling",
    question: "What must be checked before using any electrical hand tool?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker inspecting a drill's power cord and plug before starting work",
    options: {
      A: "Nothing — just plug it in and go",
      B: "The cord, plug and casing for damage or exposed wires",
      C: "Only the color of the tool",
      D: "Only that the tool is the newest model"
    },
    correct: "B"
  },
  {
    category: "Tools Handling",
    question: "What is the correct way to bring tools up a ladder?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker climbing a ladder with tools secured in a waist tool belt, hands free on rails",
    options: {
      A: "Carry them in one hand while climbing",
      B: "Use a tool belt, pouch, or hoist line, keeping both hands free to climb",
      C: "Throw them up to a co-worker",
      D: "Hold them in your teeth"
    },
    correct: "B"
  },
  {
    category: "Tools Handling",
    question: "Before using an angle grinder, what must be verified?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker checking a grinder disc's rated RPM label against the tool before starting",
    options: {
      A: "That the disc matches the tool's rated speed and the guard is fitted",
      B: "That the disc is any size that fits by force",
      C: "That the operator is wearing sandals",
      D: "That the guard has been removed for a clear view"
    },
    correct: "A"
  },
  {
    category: "Tools Handling",
    question: "What should compressed air never be used for on site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker pointing a compressed-air nozzle at a co-worker's dusty jacket, air blasting into skin",
    options: {
      A: "Cleaning debris from machinery, per equipment manual",
      B: "Blowing dust or dirt off a worker's clothing or skin",
      C: "Inflating tires to the rated pressure",
      D: "Powering pneumatic tools"
    },
    correct: "B"
  },
  {
    category: "Tools Handling",
    question: "How should electrical extension cords be used on a construction site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Single heavy-duty rated extension cord running along a dry, elevated path to a tool",
    options: {
      A: "Daisy-chained (plugged into each other) indefinitely",
      B: "Rated for the load, inspected, and not daisy-chained or run through water",
      C: "Left submerged in puddles if needed",
      D: "Any household cord will do for heavy tools"
    },
    correct: "B"
  },
  {
    category: "Tools Handling",
    question: "What should be done with a damaged or malfunctioning tool?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker attaching a red 'Do Not Use' tag to a cracked drill and setting it aside",
    options: {
      A: "Keep using it carefully until it fully breaks",
      B: "Tag it 'Do Not Use' and remove it from service immediately",
      C: "Hide it so no one asks questions",
      D: "Pass it to a new worker without mentioning the fault"
    },
    correct: "B"
  },
  {
    category: "Electrical",
    question: "What is the minimum safe clearance distance for equipment working near overhead power lines (up to 50kV)?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Crane boom working near overhead power lines with a clearly marked minimum-distance zone",
    options: {
      A: "About 3 m / 10 feet",
      B: "30 cm / 1 foot",
      C: "No clearance is required if the operator is careful",
      D: "Only 1 m is enough for any voltage"
    },
    correct: "A"
  },
  {
    category: "Electrical",
    question: "Is it safe to operate electrical tools with wet hands or in standing water?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker about to plug in a drill while standing in a puddle — warning symbol shown",
    options: {
      A: "Yes, as long as you work quickly",
      B: "No — never operate electrical equipment with wet hands or in water",
      C: "Yes, if the tool looks new",
      D: "Only during rainy season"
    },
    correct: "B"
  },
  {
    category: "Electrical",
    question: "What is Lockout-Tagout (LOTO) used for?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker applying a padlock and warning tag to an isolated electrical panel before maintenance",
    options: {
      A: "Locking a storage container",
      B: "De-energizing and isolating equipment before maintenance or repair",
      C: "Tagging tools with the owner's name",
      D: "Locking the site gate at night"
    },
    correct: "B"
  },
  {
    category: "Electrical",
    question: "What does a Ground Fault Circuit Interrupter (GFCI) protect against?",
    image: "assets/question-placeholder.svg",
    imageCaption: "GFCI outlet on a temporary power board, tripping the moment a leakage occurs near water",
    options: {
      A: "Electric shock, by cutting power when current leakage is detected",
      B: "Rust on metal tools",
      C: "Overheating of concrete",
      D: "Dust build-up in generators"
    },
    correct: "A"
  },
  {
    category: "Electrical",
    question: "What should a worker do if they find a damaged electrical cable on site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker pointing out a cracked cable to a supervisor, cable tagged out and isolated",
    options: {
      A: "Repair it with tape and keep using it",
      B: "Report it, isolate/de-energize it, and have it replaced by a qualified person",
      C: "Ignore it if it still seems to work",
      D: "Step over it carefully and continue"
    },
    correct: "B"
  },
  {
    category: "Electrical",
    question: "Who is permitted to work on a live (energized) electrical panel?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Qualified electrician in insulated gloves working on an open panel with proper PPE",
    options: {
      A: "Any worker who feels confident",
      B: "Only an authorized, qualified electrician following proper safety procedure",
      C: "Any supervisor, regardless of training",
      D: "New workers, as on-the-job training"
    },
    correct: "B"
  },
  {
    category: "Electrical",
    question: "How should temporary electrical wiring be routed on a construction site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Temporary power cable routed overhead on stands, clear of the walking path",
    options: {
      A: "Across walkways where people will trip on it",
      B: "Overhead or protected/covered, kept clear of walkways and water",
      C: "Through standing water for a shortcut",
      D: "Loosely coiled in the mud"
    },
    correct: "B"
  },
  {
    category: "Scaffolding",
    question: "What must a scaffold's base rest on?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Scaffold base with base plates on solid, level mud sills at ground level",
    options: {
      A: "Loose soil with no support",
      B: "A level, sound footing such as base plates or mud sills",
      C: "Stacked bricks that are not fixed",
      D: "Anything available, stability doesn't matter"
    },
    correct: "B"
  },
  {
    category: "Scaffolding",
    question: "What happens if a scaffold's rated load capacity is exceeded?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Overloaded scaffold platform stacked with excess material, visibly bending",
    options: {
      A: "Nothing, capacity ratings are only a guideline",
      B: "It risks structural failure or collapse",
      C: "The scaffold automatically gets stronger",
      D: "It only matters for scaffolds above 50 storeys"
    },
    correct: "B"
  },
  {
    category: "Scaffolding",
    question: "Who is authorized to erect, alter, or dismantle a scaffold?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Trained scaffolder with certification badge assembling scaffold tubes and couplers",
    options: {
      A: "Any available worker",
      B: "A trained and designated competent person",
      C: "Only the site security guard",
      D: "Whoever arrives first that morning"
    },
    correct: "B"
  },
  {
    category: "Scaffolding",
    question: "What is required for a scaffold platform's decking/planking?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Fully planked scaffold platform with tight-fitting boards edge to edge",
    options: {
      A: "It can have large gaps, as long as most of it is covered",
      B: "It must be fully planked/decked with no dangerous gaps",
      C: "Only half the platform needs boards",
      D: "Loose boards resting unsecured are fine"
    },
    correct: "B"
  },
  {
    category: "Scaffolding",
    question: "What should a worker do if they notice a scaffold is missing a guardrail?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker stopping at scaffold access point, pointing out a missing guardrail to supervisor with a stop sign",
    options: {
      A: "Use it anyway and be extra careful",
      B: "Not use it, and report it immediately to a supervisor for repair",
      C: "Add a rope themselves and continue",
      D: "Only avoid the exact missing section"
    },
    correct: "B"
  },
  {
    category: "Excavation",
    question: "At what trench depth is a protective system (sloping, shoring, or shielding) generally required?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Cross-section of a trench deeper than 1.5m with sloped sides or a shoring/trench box installed",
    options: {
      A: "5 feet (1.5 m) or deeper",
      B: "Only below 50 feet",
      C: "Protective systems are never required for trenches",
      D: "Only if it is raining"
    },
    correct: "A"
  },
  {
    category: "Excavation",
    question: "How far back from a trench edge should excavated soil (spoil) be placed?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Trench with the spoil pile set back a measured distance from the edge, dimension line shown",
    options: {
      A: "At least 2 feet (0.6 m) back from the edge",
      B: "Right at the very edge",
      C: "Distance doesn't matter",
      D: "Only 2 inches back is enough"
    },
    correct: "A"
  },
  {
    category: "Excavation",
    question: "Which of these is NOT a recognized trench protective system?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Four trench cross-sections shown side by side for comparison",
    options: {
      A: "Sloping the trench walls",
      B: "Shoring the trench walls",
      C: "Using a trench box/shield",
      D: "Standing a worker at the bottom to hold the walls by hand"
    },
    correct: "D"
  },
  {
    category: "Excavation",
    question: "What must be done before starting any excavation work?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Utility locator marking coloured lines on the ground before digging begins, excavator waiting",
    options: {
      A: "Identify and mark underground utilities (gas, electric, water lines)",
      B: "Just start digging and see what's there",
      C: "Excavation planning is only needed for very large sites",
      D: "Ask a passerby if they know what's underground"
    },
    correct: "A"
  },
  {
    category: "Excavation",
    question: "Why might a deep trench need atmospheric (gas) testing before entry?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker holding a gas detector at the trench entrance before climbing down",
    options: {
      A: "Hazardous or oxygen-deficient gases can accumulate in deep or enclosed excavations",
      B: "To check if it's a good place for lunch",
      C: "Gas testing is never needed in trenches",
      D: "Only needed if the trench has a paint smell"
    },
    correct: "A"
  },
  {
    category: "Civil",
    question: "What must be done to protruding reinforcement (rebar) ends on a site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Row of vertical rebar with orange safety caps fitted on every exposed tip",
    options: {
      A: "Leave them exposed and sharp",
      B: "Cap them with rebar caps or protective covers to prevent impalement injuries",
      C: "Bend them flat only if convenient",
      D: "Mark them with tape only, no cap needed"
    },
    correct: "B"
  },
  {
    category: "Civil",
    question: "When can formwork/shuttering be safely removed from a concrete structure?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Engineer checking a concrete strength/curing chart before authorizing formwork removal",
    options: {
      A: "As soon as the concrete looks dry on the surface",
      B: "Only after the concrete has reached adequate strength, per the engineer's schedule",
      C: "Whenever it's convenient for the schedule",
      D: "Immediately after pouring, to save time"
    },
    correct: "B"
  },
  {
    category: "Civil",
    question: "What is essential before starting demolition work on a structure?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Engineer reviewing a structural survey and demolition sequence plan on site before work begins",
    options: {
      A: "A pre-demolition survey and an approved method statement/sequence",
      B: "Just start from the top and knock it down randomly",
      C: "No planning is required for small structures",
      D: "Only the machine operator's personal judgement"
    },
    correct: "A"
  },
  {
    category: "Civil",
    question: "What is a key hazard when operating a concrete pump line/hose?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker keeping clear distance from a pressurized concrete pump hose with a blockage warning",
    options: {
      A: "The hose whipping or the line blocking/bursting under pressure",
      B: "The concrete being too colorful",
      C: "The pump being too quiet",
      D: "There are no hazards with concrete pump hoses"
    },
    correct: "A"
  },
  {
    category: "Civil",
    question: "What should be limited when stacking bricks, blocks, or masonry units on site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Brick stack at a safe, stable height compared to an unsafe over-stacked pile",
    options: {
      A: "The stacking height, to prevent the stack from toppling",
      B: "Nothing — stack as high as physically possible",
      C: "Only the color of the bricks used",
      D: "The stacking pattern, but not the height"
    },
    correct: "A"
  },
  {
    category: "Civil",
    question: "What precaution is needed for a newly built, unsupported freestanding masonry wall?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Freshly built brick wall supported by diagonal timber props against wind load",
    options: {
      A: "Temporary bracing/propping until it gains adequate strength or is tied into the structure",
      B: "No precaution needed once the mortar looks dry",
      C: "Push against it to test its strength",
      D: "Leave it exposed to strong wind with no support"
    },
    correct: "A"
  },
  {
    category: "Fire Safety",
    question: "Which fire extinguisher class is designed for ordinary combustibles like wood and paper?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Extinguisher labeled 'Class A' beside a small wood/paper fire",
    options: {
      A: "Class A",
      B: "Class C",
      C: "Class D",
      D: "Class K"
    },
    correct: "A"
  },
  {
    category: "Fire Safety",
    question: "Which fire extinguisher type is safe to use on an electrical fire?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker aiming a CO2/Class C extinguisher at a sparking electrical panel fire",
    options: {
      A: "A Class C (non-conductive agent) extinguisher",
      B: "A plain water extinguisher",
      C: "Any extinguisher works the same on electrical fires",
      D: "Throwing water directly on the panel"
    },
    correct: "A"
  },
  {
    category: "Fire Safety",
    question: "What does the 'PASS' technique for using a fire extinguisher stand for?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Four-panel sequence: pulling the pin, aiming the nozzle, squeezing the handle, sweeping side to side at the base of a fire",
    options: {
      A: "Pull, Aim, Squeeze, Sweep",
      B: "Push, Alarm, Stop, Shout",
      C: "Point, Activate, Spray, Stand-by",
      D: "Pull, Alert, Spray, Stop"
    },
    correct: "A"
  },
  {
    category: "Fire Safety",
    question: "How should flammable materials (fuel, solvents, gas cylinders) be stored on site?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Ventilated flammable-storage cabinet positioned well away from a welding station",
    options: {
      A: "In a ventilated area/cabinet, away from ignition sources and heat",
      B: "Stacked next to the welding/grinding area",
      C: "Inside the site office next to heaters",
      D: "Storage location doesn't matter as long as it's labeled"
    },
    correct: "A"
  },
  {
    category: "Fire Safety",
    question: "During a site fire evacuation, what should workers avoid using?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Workers evacuating via marked stairwell while an elevator shows a crossed-out 'do not use' sign",
    options: {
      A: "The marked emergency exit stairs",
      B: "Elevators/lifts",
      C: "The muster/assembly point",
      D: "The site's fire alarm"
    },
    correct: "B"
  },
  {
    category: "Crane & Rigging",
    question: "Is it ever safe to stand or walk beneath a suspended (crane-lifted) load?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Crane lifting a load overhead with a clearly marked exclusion zone on the ground beneath it",
    options: {
      A: "No — never stand or walk under a suspended load",
      B: "Yes, briefly, if you move quickly",
      C: "Yes, if the crane operator waves you through",
      D: "Yes, as long as you're wearing a hard hat"
    },
    correct: "A"
  },
  {
    category: "Crane & Rigging",
    question: "What is the purpose of a tag line attached to a suspended load?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker on the ground holding a tag line, steadying a suspended load as it swings",
    options: {
      A: "To help control the load's rotation and swing from the ground",
      B: "To decorate the load for visibility",
      C: "To measure the load's weight",
      D: "To power the crane's hydraulics"
    },
    correct: "A"
  },
  {
    category: "Crane & Rigging",
    question: "What must be checked before a crane lift begins?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Rigger inspecting slings and checking a load chart against the crane's radius/capacity before lifting",
    options: {
      A: "Rigging/slings condition and the load chart for capacity vs. lift weight/radius",
      B: "Only that the crane is painted the right color",
      C: "Nothing — the operator can judge it by eye",
      D: "Only the time of day"
    },
    correct: "A"
  },
  {
    category: "Crane & Rigging",
    question: "Who should direct a crane operator when the load path is not fully visible?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Certified signal person giving standard crane hand signals to the operator in the cab",
    options: {
      A: "A trained, designated signal person using standard hand signals or radio",
      B: "Any bystander who happens to be nearby",
      C: "No one — the operator should guess",
      D: "The load itself, since it can't move on its own"
    },
    correct: "A"
  },
  {
    category: "Crane & Rigging",
    question: "What is the correct manual lifting technique for a heavy object?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Side-by-side comparison of correct vs incorrect lifting posture for a heavy box",
    options: {
      A: "Bend the knees, keep the back straight, and hold the load close to the body",
      B: "Bend at the waist with straight legs and lift far from the body",
      C: "Twist the spine while lifting to save time",
      D: "Lift with one hand while the other holds a phone"
    },
    correct: "A"
  },
  {
    category: "General EHS",
    question: "What kind of tasks typically require a formal 'Permit to Work' before starting?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker filling out and getting sign-off on a Permit to Work form before hot work/confined-space entry",
    options: {
      A: "High-risk activities such as hot work, confined-space entry, or work at height",
      B: "Any activity, no matter how minor, including a coffee break",
      C: "Permits are never used in construction",
      D: "Only tasks the supervisor personally dislikes"
    },
    correct: "A"
  },
  {
    category: "General EHS",
    question: "Why is it important to report a near-miss, even if no one was injured?",
    image: "assets/question-placeholder.svg",
    imageCaption: "Worker reporting a near-miss (e.g., a dropped tool that just missed someone) to a supervisor using a report form",
    options: {
      A: "It helps identify and fix hazards before they cause a real injury",
      B: "It's just paperwork with no real value",
      C: "Only injuries need to be reported, near-misses don't matter",
      D: "Reporting a near-miss will always result in punishment, so it should be avoided"
    },
    correct: "A"
  }
];

// Seconds allowed per question
var TIME_PER_QUESTION = 30;
